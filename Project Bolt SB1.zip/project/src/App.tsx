import React, { useEffect, useState } from 'react';
import { Bitcoin } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import { SearchBar } from './components/SearchBar';
import { GifGrid } from './components/GifGrid';
import { Pagination } from './components/Pagination';
import { useDebounce } from './hooks/useDebounce';
import type { GiphyResponse } from './types';

const GIPHY_API_KEY = 'lhl8u8tQ4uWW5yiArEfxQ7ERvsmpYgQw';
const ITEMS_PER_PAGE = 100;

function App() {
  const [search, setSearch] = useState('bitcoin');
  const [gifs, setGifs] = useState<GiphyResponse['data']>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  
  const debouncedSearch = useDebounce(search, 500);

  useEffect(() => {
    const fetchGifs = async () => {
      setLoading(true);
      try {
        const response = await fetch(
          `https://api.giphy.com/v1/gifs/search?api_key=${GIPHY_API_KEY}&q=${debouncedSearch}&limit=${ITEMS_PER_PAGE}&offset=${currentPage * ITEMS_PER_PAGE}&rating=g`
        );
        const data: GiphyResponse = await response.json();
        setGifs(data.data);
        setTotalPages(Math.ceil(data.pagination.total_count / ITEMS_PER_PAGE));
      } catch (error) {
        console.error('Error fetching GIFs:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchGifs();
  }, [debouncedSearch, currentPage]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="bottom-center" />
      
      {/* Header */}
      <header className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white py-8 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center justify-center gap-3 mb-8">
            <Bitcoin className="w-10 h-10" />
            <h1 className="text-4xl font-bold">BitcoinGIFS</h1>
          </div>
          <SearchBar value={search} onChange={setSearch} />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto max-w-7xl px-4 py-8">
        <GifGrid gifs={gifs} loading={loading} />
        
        {!loading && gifs.length > 0 && (
          <div className="mt-8">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}

        {!loading && gifs.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No GIFs found. Try a different search term!</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-4 px-4">
        <div className="container mx-auto max-w-7xl text-center text-gray-500">
          Powered by GIPHY
        </div>
      </footer>
    </div>
  );
}

export default App;