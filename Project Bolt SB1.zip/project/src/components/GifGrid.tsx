import React from 'react';
import { Download, Link as LinkIcon } from 'lucide-react';
import toast from 'react-hot-toast';
import type { GiphyGif } from '../types';

interface GifGridProps {
  gifs: GiphyGif[];
  loading: boolean;
}

export function GifGrid({ gifs, loading }: GifGridProps) {
  const copyUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('URL copied to clipboard!');
    } catch (error) {
      toast.error('Failed to copy URL');
    }
  };

  const downloadGif = async (url: string, title: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `${title}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      toast.error('Failed to download GIF');
    }
  };

  if (loading) {
    return (
      <div className="grid grid-cols-5 gap-4">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="aspect-square bg-gray-200 animate-pulse rounded-lg"
          />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {gifs.map((gif) => (
        <div
          key={gif.id}
          className="relative group rounded-lg overflow-hidden bg-black/5"
        >
          <img
            src={gif.images.fixed_width.url}
            alt={gif.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
            <button
              onClick={() => copyUrl(gif.images.original.url)}
              className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
              title="Copy URL"
            >
              <LinkIcon className="w-5 h-5 text-white" />
            </button>
            <button
              onClick={() => downloadGif(gif.images.original.url, gif.title)}
              className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
              title="Download MP4"
            >
              <Download className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}